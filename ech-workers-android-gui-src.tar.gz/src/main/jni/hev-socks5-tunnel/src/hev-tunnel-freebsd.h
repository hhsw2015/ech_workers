/*
 ============================================================================
 Name        : hev-tunnel-freebsd.h
 Author      : hev <r@hev.cc>
 Copyright   : Copyright (c) 2023 - 2025 hev
 Description : Tunnel on FreeBSD
 ============================================================================
 */

#ifndef __HEV_TUNNEL_FREEBSD_H__
#define __HEV_TUNNEL_FREEBSD_H__

#endif /* __HEV_TUNNEL_FREEBSD_H__ */
